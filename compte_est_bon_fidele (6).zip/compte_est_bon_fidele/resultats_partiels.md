# Résultats réellement exécutés

Les temps sont ceux de l'environnement d'exécution utilisé ici ; ils peuvent varier d'une machine à l'autre.
Les largeurs et hauteurs correspondent aux nœuds générés dans l'arbre exploré, y compris les feuilles invalides créées par l'ajout d'un opérateur lorsque l'expression est déjà réduite à une seule valeur.

| Essai | Parcours | Nœuds évalués | Temps (s) | Taille max pile/file | Hauteur max | Largeur max | Résultat |
|---|---|---:|---:|---:|---:|---:|---|
| Date (50, 4, 100, 2, 7, 3 → 526) | DFS itératif | 4 345 | 0,010920 | 41 | 12 | 2 472 | Trouvé |
| Date (50, 4, 100, 2, 7, 3 → 526) | DFS récursif | 11 088 | 0,028515 | non mesurée directement | 12 | 6 108 | Trouvé |
| Date (50, 4, 100, 2, 7, 3 → 526) | BFS | — | — | — | — | — | Non terminé en 300 s |
| Impossible (7, 7, 8, 9, 9, 50 → 667) | DFS itératif | — | > 300 s | — | — | — | Non terminé |
| Impossible (7, 7, 8, 9, 9, 50 → 667) | DFS récursif | — | > 300 s | — | — | — | Non terminé |
| Impossible (7, 7, 8, 9, 9, 50 → 667) | BFS | — | — | — | — | — | Non exécuté : coût attendu très élevé avec pop(0) |
| Ardu (2, 10, 10, 25, 50, 75 → 214) | DFS itératif | 168 328 | 0,421089 | 42 | 12 | 104 704 | Trouvé |
| Ardu (2, 10, 10, 25, 50, 75 → 214) | DFS récursif | 2 942 162 | 6,614389 | non mesurée directement | 12 | 1 664 152 | Trouvé |
| Ardu (2, 10, 10, 25, 50, 75 → 214) | BFS | — | — | — | — | — | Non exécuté |

## Expressions trouvées

- Date, DFS itératif : `3 7 * 2 - 100 + 4 * 50 +`.
- Date, DFS récursif : `50 4 100 2 - 7 3 * + * +`.
- Ardu, DFS itératif : `75 50 * 2 * 10 - 25 10 + /`.
- Ardu, DFS récursif : `2 50 75 * * 10 - 10 25 + /`.

## Vérification minimale du BFS

Le parcours BFS a été exécuté sur le petit cas `[1, 2]`, cible `3` : 18 nœuds évalués, 14 éléments au maximum dans la file, hauteur 3, largeur 10, solution `[1, 2, '+']`. Ce test valide le fonctionnement du code, mais ne remplace pas les essais à six cartons.
